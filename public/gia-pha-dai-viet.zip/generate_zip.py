import os
import zipfile
import shutil

print("Starting packaging process...")

# Ensure public and html_exports directories exist
os.makedirs("public/html_exports", exist_ok=True)
os.makedirs("html_exports", exist_ok=True)

# Build HTML template generator
def wrap_html(title, body_content):
    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" name="viewport"/>
  <title>{title} - Gia Phả Đại Việt</title>
  <!-- Google Fonts & Material Symbols -->
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""/>
  <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Noto+Serif:ital,wght@0,600;0,700;1,600;1,700&display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {{
      font-family: 'Be Vietnam Pro', sans-serif;
      background-color: #fff8f6;
      color: #261811;
      margin: 0;
      padding: 0;
    }}
    .font-serif-heritage {{ font-family: 'Noto Serif', serif; }}
    .no-scrollbar::-webkit-scrollbar {{ display: none; }}
    .no-scrollbar {{ -ms-overflow-style: none; scrollbar-width: none; }}
  </style>
</head>
<body class="bg-[#fff8f6] text-[#261811] antialiased">
{body_content}
</body>
</html>"""

# HTML Navigation Hub
hub_html = """<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <title>Gia Phả Đại Việt - Danh Mục Màn Hình Độc Lập</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""/>
  <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Noto+Serif:wght@600;700&display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#fff8f6] text-[#261811] min-h-screen p-4 sm:p-8 font-sans">
  <div class="max-w-3xl mx-auto flex flex-col gap-6">
    <div class="bg-[#8b1e1e] text-white p-6 rounded-2xl shadow-lg flex items-center justify-between">
      <div>
        <span class="text-xs text-[#ffe08e] font-bold uppercase tracking-wider">Họ Nguyễn • Đệ Nhị Chi</span>
        <h1 class="text-2xl font-bold font-serif mt-1">Danh Mục 12 Màn Hình HTML Độc Lập</h1>
        <p class="text-xs text-[#ffdad6] mt-1">Có thể mở trực tiếp trên mọi trình duyệt web không cần cài đặt</p>
      </div>
      <a href="../gia-pha-dai-viet.zip" class="bg-[#fed255] text-[#735a00] font-bold text-xs px-4 py-2.5 rounded-xl shadow flex items-center gap-1.5 hover:bg-[#ffe08e]">
        <span class="material-symbols-outlined text-[18px]">download</span>
        Tải Tệp Nén ZIP
      </a>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <a href="01_trang_chu.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">01</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">01. Trang Chủ</h3>
          <p class="text-xs text-[#58413f]">Tôn vinh dòng tộc, giỗ tổ sắp tới, tin tức</p>
        </div>
      </a>
      <a href="02_cay_gia_pha.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">02</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">02. Cây Gia Phả (Phả Đồ)</h3>
          <p class="text-xs text-[#58413f]">Sơ đồ cây 7 đời, phóng to thu nhỏ, chi tiết</p>
        </div>
      </a>
      <a href="03_thanh_vien.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">03</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">03. Danh Bạ Thành Viên</h3>
          <p class="text-xs text-[#58413f]">Danh bạ A-Z, lọc theo còn sống / đã mất</p>
        </div>
      </a>
      <a href="04_them_thanh_vien.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">04</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">04. Thêm Thành Viên</h3>
          <p class="text-xs text-[#58413f]">Khai báo huyết thống, ảnh, ngày sinh/tử</p>
        </div>
      </a>
      <a href="05_lich_te_tu.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">05</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">05. Lịch Tế Tự & Kỵ Nhật</h3>
          <p class="text-xs text-[#58413f]">Lịch song hành Âm - Dương theo tháng</p>
        </div>
      </a>
      <a href="06_chi_tiet_le_gio.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">06</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">06. Chi Tiết Lễ Giỗ Tổ</h3>
          <p class="text-xs text-[#58413f]">Nghi lễ 4 bước, đếm khách dự lễ, tâm hương</p>
        </div>
      </a>
      <a href="07_them_su_kien.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">07</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">07. Thêm Sự Kiện / Ngày Giỗ</h3>
          <p class="text-xs text-[#58413f]">Lặp lại âm lịch, nhắc nhở trước lễ</p>
        </div>
      </a>
      <a href="08_quan_tri_dong_ho.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">08</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">08. Quản Trị Dòng Họ</h3>
          <p class="text-xs text-[#58413f]">Mã mời gia tộc, duyệt đơn, phân quyền</p>
        </div>
      </a>
      <a href="09_xuat_va_sao_luu.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">09</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">09. Xuất PDF & Sao Lưu</h3>
          <p class="text-xs text-[#58413f]">In khổ A4/A3, tải GEDCOM, Excel, sao lưu</p>
        </div>
      </a>
      <a href="10_ca_nhan.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">10</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">10. Cá Nhân & Cài Đặt</h3>
          <p class="text-xs text-[#58413f]">Vị trí phả đồ cá nhân, cài đặt bảo mật</p>
        </div>
      </a>
      <a href="11_dang_nhap.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">11</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">11. Đăng Nhập & Đăng Ký</h3>
          <p class="text-xs text-[#58413f]">Đăng nhập SĐT, Zalo, Google</p>
        </div>
      </a>
      <a href="12_khoi_tao_dong_ho.html" class="p-4 bg-white rounded-xl shadow-xs border border-[#dfbfbc]/40 hover:border-[#6a020a] hover:bg-[#fff1eb] transition-all flex items-center gap-3">
        <span class="w-10 h-10 rounded-lg bg-[#ffeae0] text-[#6a020a] flex items-center justify-center font-bold text-sm shrink-0">12</span>
        <div>
          <h3 class="font-bold text-sm text-[#261811]">12. Khởi Tạo / Nhập Mã Dòng Họ</h3>
          <p class="text-xs text-[#58413f]">Tạo mới tộc phả hoặc nhập mã 6 ký tự</p>
        </div>
      </a>
    </div>
  </div>
</body>
</html>"""

with open("html_exports/index.html", "w", encoding="utf-8") as f:
    f.write(hub_html)
with open("public/html_exports/index.html", "w", encoding="utf-8") as f:
    f.write(hub_html)

# Create zip file of whole workspace excluding node_modules, .git, etc.
zip_filename = "gia-pha-dai-viet.zip"
public_zip = "public/gia-pha-dai-viet.zip"

excluded_dirs = {'.git', 'node_modules', '.cache', 'dist'}
excluded_files = {zip_filename, 'bun.lock'}

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in excluded_dirs and not d.startswith('.')]
        for file in files:
            if file in excluded_files or file.endswith('.pyc'):
                continue
            filepath = os.path.join(root, file)
            # Store with clean relative path
            arcname = os.path.relpath(filepath, '.')
            zipf.write(filepath, arcname)

# Copy to public so Vite serves it for instant web download
shutil.copyfile(zip_filename, public_zip)

file_size_kb = os.path.getsize(zip_filename) / 1024
print(f"Zip archive successfully created: {zip_filename} ({file_size_kb:.1f} KB)")
print(f"Public web-downloadable zip created: {public_zip}")
